## HTML Simple Template

This is a simple HTML template that can be used to create a simple HTML page(s).

## How to run

1. Run the follwing command in your terminal:
```bash
live-server --no-browser
```

2. Refresh the URL in simple browser to see the output